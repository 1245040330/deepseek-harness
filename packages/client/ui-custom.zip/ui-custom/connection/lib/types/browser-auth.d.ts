import type { Context } from '@deepseek-ai/cordis';
import type { ConnectionIndexRequest, ConnectionIndexResponse, ConnectionTrustRequest } from './rpc.ts';
export interface AgentInfo {
    sysPrompt: string;
    name: string;
    model: string;
    pluginList: string[];
}
export interface LoginInfo {
    path: string;
    agentId: string;
    agentInfo: AgentInfo;
    defaultContext: Record<string, unknown>;
}
export interface BusinessAuthConfig {
    loginEndpoint: string;
    loginTimeoutMs: number;
    cookieMaxAgeDays: number;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        businessAuth: BrowserAuth;
    }
}
export declare function loginInfo(value: unknown): LoginInfo;
/** Process-owned opaque cookies; original launch tokens and cookies are never accepted. */
export declare class BrowserAuth {
    private readonly config;
    private readonly sessions;
    private readonly lifetime;
    constructor(ctx: Context, config: BusinessAuthConfig);
    lookup(request: ConnectionTrustRequest, secure?: boolean): LoginInfo | undefined;
    isAuthenticated(request: ConnectionTrustRequest, secure?: boolean): boolean;
    authenticatedUrl(baseUrl: string): string;
    /** Synchronous consumers may only serve pages already admitted by the business entrance. */
    authorizeIndex(request: ConnectionIndexRequest, response: ConnectionIndexResponse, secure?: boolean): boolean;
    authorizeBusinessIndex(request: ConnectionIndexRequest, response: ConnectionIndexResponse, secure?: boolean): Promise<boolean>;
}
//# sourceMappingURL=browser-auth.d.ts.map